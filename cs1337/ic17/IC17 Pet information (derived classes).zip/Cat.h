#ifndef CATH
#define CATH

#include <string>
#include "Pet.h"

class Cat : public Pet {
	
};

#endif