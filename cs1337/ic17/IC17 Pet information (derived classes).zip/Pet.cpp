
#include "Pet.h"
#include <iostream>
#include <string>
using namespace std;

// default constructor
Pet::Pet()
{
    petName = "Tommy";
    petAge = 10;
}

// write the paramterized constructor and other getters and setters functions 


void Pet::PrintInfo() {
	cout << "Pet Information: " << endl;
	cout << "   Name: " << petName << endl;
	cout << "   Age: " << petAge << endl;
}
