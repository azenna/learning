#include "Cat.h"
#include <iostream>
#include <string>
using namespace std;

Cat:: Cat(): Pet()
{
    catBreed = "Rajapalayam";
}

// write the paramterized constructor and other getters, setters and print functions 